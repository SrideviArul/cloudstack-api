package com.acs.api.entity;

import java.util.List;

public class QueryAsyncJobResultResponse {
  
	private String accountId;
	
	private List<NetworkResponse> network;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public List<NetworkResponse> getNetwork() {
		return network;
	}

	public void setNetwork(List<NetworkResponse> network) {
		this.network = network;
	}

}
