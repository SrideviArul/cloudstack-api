package com.acs.api.entity;

import jakarta.persistence.Entity;
/**
 * 
 * Already created network will delete
 */
@Entity
public class DeleteNetworkResponse {

	private String jobId;
	
	private String displayText;
	
	private String success;

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}	
}
