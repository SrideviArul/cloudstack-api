package com.acs.api.entity;

import jakarta.persistence.Entity;

/** Create network fields **/
@Entity
public class CreateNetworkRequest {
	    
	    private String zoneId;
	    
	    private String name;
	    
	    private String displayText;
	    
	    private String networkOfferingId;
	    
	    private String gateway;
	    
	    private String netmask;

		public String getZoneId() {
			return zoneId;
		}

		public void setZoneId(String zoneId) {
			this.zoneId = zoneId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDisplayText() {
			return displayText;
		}

		public void setDisplayText(String displayText) {
			this.displayText = displayText;
		}

		public String getNetworkOfferingId() {
			return networkOfferingId;
		}

		public void setNetworkOfferingId(String networkOfferingId) {
			this.networkOfferingId = networkOfferingId;
		}

		public String getGateway() {
			return gateway;
		}

		public void setGateway(String gateway) {
			this.gateway = gateway;
		}

		public String getNetmask() {
			return netmask;
		}

		public void setNetmask(String netmask) {
			this.netmask = netmask;
		}
}
