package com.acs.api.entity;

public class ListNetworkRequest {
	
	private String id;
	
	private String zoneId;
	
	private String account;

	private String aclType;
	
	private String associatedNetworkId;
	
	private String canUseForDeploy;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getZoneId() {
		return zoneId;
	}

	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAclType() {
		return aclType;
	}

	public void setAclType(String aclType) {
		this.aclType = aclType;
	}

	public String getAssociatedNetworkId() {
		return associatedNetworkId;
	}

	public void setAssociatedNetworkId(String associatedNetworkId) {
		this.associatedNetworkId = associatedNetworkId;
	}

	public String getCanUseForDeploy() {
		return canUseForDeploy;
	}

	public void setCanUseForDeploy(String canUseForDeploy) {
		this.canUseForDeploy = canUseForDeploy;
	}

	public String getDisplayNetwork() {
		return displayNetwork;
	}

	public void setDisplayNetwork(String displayNetwork) {
		this.displayNetwork = displayNetwork;
	}

	public String getDomainId() {
		return domainId;
	}

	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}

	public String getForVPC() {
		return forVPC;
	}

	public void setForVPC(String forVPC) {
		this.forVPC = forVPC;
	}

	private String  displayNetwork;
	
	private String domainId;
	
	private String forVPC;
	
	
	
}
