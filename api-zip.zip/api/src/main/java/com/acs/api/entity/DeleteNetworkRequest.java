package com.acs.api.entity;

public class DeleteNetworkRequest {
	
	 private  String id;
	 
	 private String forced;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getForced() {
		return forced;
	}

	public void setForced(String forced) {
		this.forced = forced;
	}
	 

}
