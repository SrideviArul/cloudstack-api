package com.acs.api.entity;

import java.util.List;

import jakarta.persistence.Entity;
/**
 * List of network to show
 */
@Entity
public class NetworkResponse {
	
	private String id;
	
	private String name;
	
	private String displayText;
	
	private String broadCastDomainType;
	
	private String associatedNetwork;
	
	private String associatedNetworkId;
	
	private String dns1;

	private String dns2;
	
	private String displayNetwork;
	

	public String getAssociatedNetwork() {
		return associatedNetwork;
	}

	public void setAssociatedNetwork(String associatedNetwork) {
		this.associatedNetwork = associatedNetwork;
	}

	public String getAssociatedNetworkId() {
		return associatedNetworkId;
	}

	public void setAssociatedNetworkId(String associatedNetworkId) {
		this.associatedNetworkId = associatedNetworkId;
	}

	public String getDns1() {
		return dns1;
	}

	public void setDns1(String dns1) {
		this.dns1 = dns1;
	}

	public String getDns2() {
		return dns2;
	}

	public void setDns2(String dns2) {
		this.dns2 = dns2;
	}

	public String getDisplayNetwork() {
		return displayNetwork;
	}

	public void setDisplayNetwork(String displayNetwork) {
		this.displayNetwork = displayNetwork;
	}

	public String getBroadCastDomainType() {
		return broadCastDomainType;
	}

	public void setBroadCastDomainType(String broadCastDomainType) {
		this.broadCastDomainType = broadCastDomainType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}
    
}
