package com.acs.api.entity;

import java.util.List;

public class ListNetworkResponse {
	 
	private String id;
	
	private String account;
	
	private String aclId;
	
	private String aclName;
	
	private String aclType;
	
	private String broadCastDomainType;
	
	private String displayText;
	
	private String displayNetwork;
	
	private String dns1;
	
	private String dns2;
	
	List<ListNetworkRequest> network;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAclId() {
		return aclId;
	}

	public void setAclId(String aclId) {
		this.aclId = aclId;
	}

	public String getAclName() {
		return aclName;
	}

	public void setAclName(String aclName) {
		this.aclName = aclName;
	}

	public String getAclType() {
		return aclType;
	}

	public void setAclType(String aclType) {
		this.aclType = aclType;
	}

	public String getBroadCastDomainType() {
		return broadCastDomainType;
	}

	public void setBroadCastDomainType(String broadCastDomainType) {
		this.broadCastDomainType = broadCastDomainType;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getDisplayNetwork() {
		return displayNetwork;
	}

	public void setDisplayNetwork(String displayNetwork) {
		this.displayNetwork = displayNetwork;
	}

	public String getDns1() {
		return dns1;
	}

	public void setDns1(String dns1) {
		this.dns1 = dns1;
	}

	public String getDns2() {
		return dns2;
	}

	public void setDns2(String dns2) {
		this.dns2 = dns2;
	}

	public List<ListNetworkRequest> getNetwork() {
		return network;
	}

	public void setNetwork(List<ListNetworkRequest> network) {
		this.network = network;
	}
	

}
