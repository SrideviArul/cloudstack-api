package com.acs.api.entity;

public class QueryAsyncJobResultRequest {
	
    private String jobId;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
}
