package com.acs.api.entity;

public class UpdateNetworkRequest {

	private String id;
	
	private String changeCIDR;
	
	private String customId;
	
	private String displayNetwork;
	
	private String displayText;
	
	private String name;
	
	private String forced;
	
	private String dns1;
	
	private String dns2;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getChangeCIDR() {
		return changeCIDR;
	}

	public void setChangeCIDR(String changeCIDR) {
		this.changeCIDR = changeCIDR;
	}

	public String getCustomId() {
		return customId;
	}

	public void setCustomId(String customId) {
		this.customId = customId;
	}

	public String getDisplayNetwork() {
		return displayNetwork;
	}

	public void setDisplayNetwork(String displayNetwork) {
		this.displayNetwork = displayNetwork;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getForced() {
		return forced;
	}

	public void setForced(String forced) {
		this.forced = forced;
	}

	public String getDns1() {
		return dns1;
	}

	public void setDns1(String dns1) {
		this.dns1 = dns1;
	}

	public String getDns2() {
		return dns2;
	}

	public void setDns2(String dns2) {
		this.dns2 = dns2;
	}
}
